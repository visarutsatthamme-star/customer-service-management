import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Vercel compatible configuration
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  eslint: {
    ignoreDuringBuilds: true,
  },
  images: {
    domains: ['script.google.com', 'script.googleusercontent.com'],
    // For Vercel deployment
    formats: ['image/webp', 'image/avif'],
  },
  // Remove standalone output for Vercel compatibility
  // Vercel handles this automatically
  experimental: {
    // Enable any experimental features if needed
  },
};

export default nextConfig;
