# 🚀 คู่มือการ Deploy ระบบไปยัง Vercel

## 📋 ภาพรวม

Vercel เป็นแพลตฟอร์มที่เหมาะสำหรับการ Deploy แอปพลิเคชัน Next.js โดยมีฟีเจอร์มากมาย เช่น:
- ⚡ **Auto Deploy** จาก Git
- 🌍 **Global CDN** ทั่วโลก
- 📊 **Analytics** ฟรี
- 🔒 **HTTPS** อัตโนมัติ
- 📱 **PWA Support**

---

## 🛠️ การเตรียมพร้อมก่อน Deploy

### ✅ **ตรวจสอบไฟล์ที่จำเป็น**
- ✅ `package.json` - ข้อมูลโปรเจค
- ✅ `next.config.ts` - คอนฟิก Next.js
- ✅ `vercel.json` - คอนฟิก Vercel
- ✅ `.env.example` - ตัวอย่าง Environment Variables
- ✅ `public/manifest.json` - PWA Manifest (ถ้ามี)
- ✅ `public/icons/` - ไอคอนแอป (ถ้ามี)

### 🔧 **การตั้งค่าที่ทำไปแล้ว**
- ✅ **Next.js Config** ปรับสำหรับ Vercel
- ✅ **Image Domains** รองรับ Google Scripts
- ✅ **TypeScript** ข้ามข้อผิดพลาด build
- ✅ **ESLint** ข้ามข้อผิดพลาด build
- ✅ **Not Found Page** สำหรับ 404

---

## 🚀 วิธีการ Deploy (3 วิธี)

### 🟢 **วิธีที่ 1: Vercel CLI (แนะนำ)**

#### **ขั้นที่ 1: ติดตั้ง Vercel CLI**
```bash
# ใช้ npx ถ้าไม่ได้ติดตั้งแบบ global
npx vercel

# หรือติดตั้งแบบ global
npm install -g vercel
vercel
```

#### **ขั้นที่ 2: Login และ Setup**
```bash
# Login ด้วย GitHub/GitLab/Bitbucket
vercel login

# เริ่มโปรเจคใหม่
vercel
```

#### **ขั้นที่ 3: ตั้งค่าโปรเจค**
```
? Set up and deploy "~/my-project"? [Y/n] y
? Which scope do you want to deploy to? Your Name
? Link to existing project? [y/N] n
? What's your project's name? customer-service-app
? In which directory is your code located? ./
? Want to override the settings? [y/N] n
```

#### **ขั้นที่ 4: Deploy**
```
🔗  Linked to yourname/customer-service-app
🔍  Inspect: https://vercel.com/yourname/customer-service-app
✅  Production: https://customer-service-app.vercel.app
```

---

### 🟡 **วิธีที่ 2: Vercel Web Interface**

#### **ขั้นที่ 1: Push ไปยัง Git**
```bash
# ถ้ายังไม่มี Git repository
git init
git add .
git commit -m "Initial commit: Customer Service Management System"

# Push ไปยัง GitHub/GitLab
git remote add origin https://github.com/yourname/customer-service.git
git push -u origin main
```

#### **ขั้นที่ 2: Import บน Vercel**
1. เปิด [vercel.com](https://vercel.com)
2. Login ด้วย GitHub/GitLab
3. คลิก **"Add New..."** > **"Project"**
4. เลือก repository ของคุณ
5. Vercel จะ detect Next.js อัตโนมัติ
6. คลิก **"Deploy"**

#### **ขั้นที่ 3: ตั้งค่า Environment Variables**
ในหน้า Project Settings:
1. ไปที่ **Settings** > **Environment Variables**
2. เพิ่ม variables จาก `.env.example`

---

### 🔵 **วิธีที่ 3: GitHub Integration (Auto Deploy)**

#### **ขั้นที่ 1: Connect GitHub**
1. บน Vercel: **Settings** > **GitHub**
2. เลือก repository ที่ต้องการ
3. Enable **Automatic Deployments**

#### **ขั้นที่ 2: Configure Deploy Rules**
```json
// vercel.json (อยู่ในโปรเจคแล้ว)
{
  "version": 2,
  "builds": [
    {
      "src": "package.json",
      "use": "@vercel/next"
    }
  ]
}
```

#### **ขั้นที่ 3: Auto Deploy**
ทุกครั้งที่ push ไปยัง main branch:
- Vercel จะ build อัตโนมัติ
- Deploy ไปยัง production
- ส่ง notification

---

## 🔧 Environment Variables ที่จำเป็น

### 📋 **ตัวแปรหลัก**
```bash
# Google Apps Script URL
NEXT_PUBLIC_GOOGLE_SCRIPT_URL=https://script.google.com/macros/s/AKfycbxP13-5puBL-IICp3erVwmOQqFtOzJPhSKdTyMl8sq-g7DZbRE7gmYufIZzIIoaRfqDyQ/exec

# App Configuration
NEXT_PUBLIC_APP_NAME=ระบบจัดการบริการลูกค้า
NEXT_PUBLIC_APP_DESCRIPTION=ระบบจัดการบริการลูกค้าภาษาไทยสำหรับธุรกิจของคุณ
```

### 🎨 **PWA Variables (ถ้าใช้ PWA)**
```bash
NEXT_PUBLIC_PWA_NAME=Customer Service
NEXT_PUBLIC_PWA_SHORT_NAME=Service
NEXT_PUBLIC_PWA_THEME_COLOR=#3b82f6
NEXT_PUBLIC_PWA_BACKGROUND_COLOR=#ffffff
NEXT_PUBLIC_ENABLE_PWA=true
```

### 📊 **Analytics (Optional)**
```bash
NEXT_PUBLIC_GOOGLE_ANALYTICS_ID=G-XXXXXXXXXX
NEXT_PUBLIC_VERCEL_ANALYTICS_ID=true
```

---

## 🛠️ การแก้ไขปัญหาที่พบบ

### ❌ **ปัญหาทั่วไป**

#### **1. Build Failed**
```bash
# ตรวจสอบ error log
vercel logs

# แก้ไขแล้ว redeploy
git add .
git commit -m "Fix build errors"
git push
```

#### **2. API Routes ไม่ทำงาน**
```typescript
// ตรวจสอบว่า export ถูกต้อง
export async function GET() {
  return NextResponse.json({ success: true });
}
```

#### **3. Images ไม่โหลด**
```typescript
// next.config.ts
images: {
  domains: ['your-domain.com', 'script.google.com'],
}
```

#### **4. Environment Variables ไม่ทำงาน**
```typescript
// ใช้ NEXT_PUBLIC_ สำหรับ client-side
const apiUrl = process.env.NEXT_PUBLIC_API_URL;
```

### 🚨 **ปัญหาเฉพาะ Vercel**

#### **1. PWA ไม่ทำงาน**
- ใช้ `next-pwa` อาจมีปัญหาบน Vercel
- ลองใช้ Vercel Edge Functions แทน
- หรือปิด PWA ชั่วคราว

#### **2. CORS Issues**
```typescript
// API route เพิ่ม CORS headers
export async function GET() {
  return NextResponse.json(data, {
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE',
    }
  });
}
```

#### **3. Static Generation Issues**
```typescript
// ใช้ dynamic rendering แทน static
export const dynamic = 'force-dynamic';
```

---

## 📱 การเปิดใช้งาน PWA บน Vercel

### 🔧 **วิธีที่ 1: Vercel Edge Functions**
```typescript
// app/sw.ts
import { NextRequest } from 'next/server';

export const config = {
  runtime: 'edge',
};

export default function handler(req: NextRequest) {
  // Service Worker logic
}
```

### 📋 **วิธีที่ 2: Manual PWA**
1. Build PWA files แยก
2. Upload ไปยัง public directory
3. ตั้งค่า headers ใน `vercel.json`

---

## 🔄 CI/CD Pipeline

### 📋 **GitHub Actions (Optional)**
```yaml
# .github/workflows/deploy.yml
name: Deploy to Vercel

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Deploy to Vercel
        uses: amondnet/vercel-action@v20
        with:
          vercel-token: ${{ secrets.VERCEL_TOKEN }}
          vercel-org-id: ${{ secrets.ORG_ID }}
          vercel-project-id: ${{ secrets.PROJECT_ID }}
```

---

## 📊 Monitoring และ Analytics

### 📈 **Vercel Analytics**
1. ไปที่ **Analytics** tab ใน Vercel
2. ดู Page Views, Visitors, Performance
3. ตรวจสอบ Web Vitals

### 🔍 **Custom Analytics**
```typescript
// lib/analytics.ts
export const trackEvent = (eventName: string, properties?: object) => {
  if (typeof window !== 'undefined' && window.gtag) {
    window.gtag('event', eventName, properties);
  }
};
```

---

## 🌍 Domain และ SSL

### 🌐 **Custom Domain**
1. ไปที่ **Settings** > **Domains**
2. เพิ่ม domain: `your-domain.com`
3. ตั้งค่า DNS records:
   ```
   CNAME -> cname.vercel-dns.com
   ```

### 🔒 **SSL Certificate**
- Vercel จัดการ SSL อัตโนมัติ
- ใช้ Let's Encrypt
- ต่ออายุอัตโนมัติ

---

## 🚀 Production Best Practices

### ⚡ **Performance**
- ✅ ใช้ Image Optimization
- ✅ Enable Caching
- ✅ ใช้ CDN (Vercel มีให้)
- ✅ ตรวจสอบ Core Web Vitals

### 🔒 **Security**
- ✅ HTTPS อัตโนมัติ
- ✅ Environment Variables ปลอดภัย
- ✅ CORS headers
- ✅ Rate limiting (ถ้าจำเป็น)

### 📱 **Mobile**
- ✅ Responsive Design
- ✅ Touch-Friendly
- ✅ PWA (ถ้าเปิด)
- ✅ Fast Loading

---

## 🎯 การทดสอบหลัง Deploy

### 🧪 **Manual Testing**
1. เปิดเว็บไซต์บน mobile/desktop
2. ทดสอบทุกฟีเจอร์
3. ตรวจสอบ API connections
4. ทดสอบ PWA (ถ้ามี)

### 🤖 **Automated Testing**
```bash
# Lighthouse CLI
npx lighthouse https://your-app.vercel.app

# หรือใน Chrome DevTools
# Audits > Run audit
```

---

## 📞 การสนับสนุน

### 🆘️ **Vercel Support**
- [Documentation](https://vercel.com/docs)
- [Status Page](https://www.vercel-status.com/)
- [Community](https://vercel.com/discord)

### 🐛 **Debug Tools**
```bash
# Vercel logs
vercel logs

# Local debugging
vercel dev

# Build debug
vercel build --debug
```

---

## 🎉 สรุปการ Deploy

### ✅ **Checklist ก่อน Deploy**
- [ ] Code ผ่าน `npm run build`
- [ ] Environment variables ตั้งค่าแล้ว
- [ ] API routes ทำงานได้
- [ ] Images โหลดได้
- [ ] Mobile responsive
- [ ] SEO meta tags

### 🚀 **Deploy Commands**
```bash
# CLI Deploy
vercel --prod

# Git Push (Auto Deploy)
git add .
git commit -m "Ready for production"
git push origin main
```

### 🎊 **หลัง Deploy**
- [ ] ทดสอบทุกหน้า
- [ ] ตรวจสอบ API endpoints
- [ ] ทดสอบบนมือถือ
- [ ] ตรวจสอบ PWA (ถ้ามี)
- [ ] ตั้งค่า domain (ถ้าจำเป็น)

---

## 🎯 **URL หลัง Deploy**

เมื่อ deploy สำเร็จ คุณจะได้:
- **Production URL**: `https://your-app-name.vercel.app`
- **Preview URLs**: `https://your-branch-name.your-app-name.vercel.app`
- **Custom Domain**: `https://your-domain.com` (ถ้าตั้งค่า)

---

🎉 **ยินดีด้วย! ระบบจัดการบริการลูกค้าของคุณพร้อมใช้งานบน Vercel แล้ว!**

🌟 **เริ่มต้นได้เลย:**
1. **Deploy**: `vercel --prod` หรือ push ไป Git
2. **Test**: เปิด URL ที่ได้
3. **Share**: แชร์ให้ทีมใช้งาน

**ระบบของคุณตอนนี้พร้อมให้บริการจริงบน Vercel!** 🚀✨