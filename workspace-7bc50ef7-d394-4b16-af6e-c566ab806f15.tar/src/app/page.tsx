'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { 
  Search, 
  Users, 
  Wrench, 
  Package, 
  Calendar,
  MapPin,
  User,
  Settings,
  TrendingUp,
  Phone,
  Mail,
  Clock,
  CheckCircle,
  AlertCircle,
  Filter,
  Download,
  RefreshCw,
  Menu,
  X,
  Home,
  Plus,
  Bell
} from 'lucide-react';

interface Customer {
  id: string;
  code: string;
  name: string;
  province: string;
  machineModel: string;
  technician: string;
  serviceFrequency: number;
  repairCount: number;
  totalPurchase: number;
  score: number;
  gradeLabel: string;
}

interface ServiceData {
  customers: Customer[];
  pm: any[];
  parts: any[];
  visits: any;
}

export default function CustomerServiceManagement() {
  const [data, setData] = useState<ServiceData | null>(null);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/service-data');
      const result = await response.json();
      
      if (result.success) {
        setData(result.data);
      } else {
        console.error('API Error:', result.error);
        setData({
          customers: [
            {
              id: "TUN002",
              code: "TUN002",
              name: "SCON",
              province: "ขอนแก่น",
              machineModel: "HB60Q-13",
              technician: "กิตติพงษ์",
              serviceFrequency: 0,
              repairCount: 0,
              totalPurchase: 0,
              score: 0,
              gradeLabel: "ในประกัน"
            }
          ],
          pm: [],
          parts: [],
          visits: {}
        });
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredCustomers = data?.customers?.filter(customer => {
    const matchesSearch = 
      customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.province.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.technician.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesFilter = 
      filterStatus === 'all' ||
      (filterStatus === 'warranty' && customer.gradeLabel === 'ในประกัน') ||
      (filterStatus === 'no-warranty' && customer.gradeLabel === 'หมดประกัน') ||
      (filterStatus === 'needs-service' && customer.repairCount > 0);
    
    return matchesSearch && matchesFilter;
  }) || [];

  const getGradeColor = (grade: string) => {
    switch (grade) {
      case 'ในประกัน': return 'bg-green-100 text-green-800 border-green-200';
      case 'หมดประกัน': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getGradeIcon = (grade: string) => {
    switch (grade) {
      case 'ในประกัน': return <CheckCircle className="w-4 h-4" />;
      case 'หมดประกัน': return <AlertCircle className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const stats = {
    totalCustomers: data?.customers?.length || 0,
    inWarranty: data?.customers?.filter(c => c.gradeLabel === 'ในประกัน').length || 0,
    outOfWarranty: data?.customers?.filter(c => c.gradeLabel === 'หมดประกัน').length || 0,
    totalRepairs: data?.customers?.reduce((sum, c) => sum + c.repairCount, 0) || 0,
    totalPurchase: data?.customers?.reduce((sum, c) => sum + c.totalPurchase, 0) || 0,
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 p-4">
        <div className="max-w-7xl mx-auto">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-3/4 mb-6"></div>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              {[1, 2, 3, 4].map(i => (
                <div key={i} className="h-24 bg-gray-200 rounded"></div>
              ))}
            </div>
            <div className="h-64 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Mobile Header */}
      <div className="bg-white shadow-sm border-b sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden"
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </Button>
              <div>
                <h1 className="text-xl lg:text-3xl font-bold text-gray-900">ระบบบริการลูกค้า</h1>
                <p className="text-xs lg:text-sm text-gray-600 hidden sm:block">Customer Service Management</p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={fetchData}>
                <RefreshCw className="w-4 h-4" />
                <span className="hidden sm:inline ml-2">รีเฟรช</span>
              </Button>
              <Button variant="outline" size="sm">
                <Bell className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Navigation Menu */}
      {mobileMenuOpen && (
        <div className="bg-white border-b lg:hidden">
          <div className="px-4 py-3 space-y-2">
            <Button variant="ghost" className="w-full justify-start" onClick={() => setMobileMenuOpen(false)}>
              <Home className="w-4 h-4 mr-2" />
              หน้าแรก
            </Button>
            <Button variant="ghost" className="w-full justify-start" onClick={() => setMobileMenuOpen(false)}>
              <Users className="w-4 h-4 mr-2" />
              ลูกค้า
            </Button>
            <Button variant="ghost" className="w-full justify-start" onClick={() => setMobileMenuOpen(false)}>
              <Calendar className="w-4 h-4 mr-2" />
              บำรุงรักษา
            </Button>
            <Button variant="ghost" className="w-full justify-start" onClick={() => setMobileMenuOpen(false)}>
              <Package className="w-4 h-4 mr-2" />
              อะไหล่
            </Button>
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Stats Cards - Mobile Optimized */}
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 lg:gap-6 mb-6">
          <Card className="p-3 lg:p-6">
            <div className="flex flex-col lg:flex-row items-center lg:justify-between space-y-2 lg:space-y-0">
              <CardTitle className="text-xs lg:text-sm font-medium">ลูกค้าทั้งหมด</CardTitle>
              <Users className="h-4 w-4 text-blue-600" />
            </div>
            <CardContent className="p-0 pt-2 lg:pt-4">
              <div className="text-xl lg:text-2xl font-bold text-blue-600">{stats.totalCustomers}</div>
              <p className="text-xs text-muted-foreground">รายการ</p>
            </CardContent>
          </Card>

          <Card className="p-3 lg:p-6">
            <div className="flex flex-col lg:flex-row items-center lg:justify-between space-y-2 lg:space-y-0">
              <CardTitle className="text-xs lg:text-sm font-medium">ในประกัน</CardTitle>
              <CheckCircle className="h-4 w-4 text-green-600" />
            </div>
            <CardContent className="p-0 pt-2 lg:pt-4">
              <div className="text-xl lg:text-2xl font-bold text-green-600">{stats.inWarranty}</div>
              <p className="text-xs text-muted-foreground">รายการ</p>
            </CardContent>
          </Card>

          <Card className="p-3 lg:p-6">
            <div className="flex flex-col lg:flex-row items-center lg:justify-between space-y-2 lg:space-y-0">
              <CardTitle className="text-xs lg:text-sm font-medium">หมดประกัน</CardTitle>
              <AlertCircle className="h-4 w-4 text-red-600" />
            </div>
            <CardContent className="p-0 pt-2 lg:pt-4">
              <div className="text-xl lg:text-2xl font-bold text-red-600">{stats.outOfWarranty}</div>
              <p className="text-xs text-muted-foreground">รายการ</p>
            </CardContent>
          </Card>

          <Card className="p-3 lg:p-6">
            <div className="flex flex-col lg:flex-row items-center lg:justify-between space-y-2 lg:space-y-0">
              <CardTitle className="text-xs lg:text-sm font-medium">การซ่อม</CardTitle>
              <Wrench className="h-4 w-4 text-orange-600" />
            </div>
            <CardContent className="p-0 pt-2 lg:pt-4">
              <div className="text-xl lg:text-2xl font-bold text-orange-600">{stats.totalRepairs}</div>
              <p className="text-xs text-muted-foreground">ครั้ง</p>
            </CardContent>
          </Card>

          <Card className="p-3 lg:p-6">
            <div className="flex flex-col lg:flex-row items-center lg:justify-between space-y-2 lg:space-y-0">
              <CardTitle className="text-xs lg:text-sm font-medium">ยอดซื้อ</CardTitle>
              <TrendingUp className="h-4 w-4 text-purple-600" />
            </div>
            <CardContent className="p-0 pt-2 lg:pt-4">
              <div className="text-lg lg:text-2xl font-bold text-purple-600">
                {stats.totalPurchase.toLocaleString('th-TH')}
              </div>
              <p className="text-xs text-muted-foreground">บาท</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="customers" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 h-auto">
            <TabsTrigger value="customers" className="flex items-center gap-2 text-xs lg:text-sm py-3">
              <Users className="w-4 h-4" />
              <span className="hidden sm:inline">ข้อมูลลูกค้า</span>
              <span className="sm:hidden">ลูกค้า</span>
            </TabsTrigger>
            <TabsTrigger value="pm" className="flex items-center gap-2 text-xs lg:text-sm py-3">
              <Calendar className="w-4 h-4" />
              <span className="hidden sm:inline">บำรุงรักษา</span>
              <span className="sm:hidden">PM</span>
            </TabsTrigger>
            <TabsTrigger value="parts" className="flex items-center gap-2 text-xs lg:text-sm py-3">
              <Package className="w-4 h-4" />
              <span className="hidden sm:inline">คลังอะไหล่</span>
              <span className="sm:hidden">อะไหล่</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="customers" className="space-y-6">
            {/* Search and Filter - Mobile Optimized */}
            <div className="space-y-4">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="ค้นหาชื่อ รหัส จังหวัด หรือช่าง..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 h-12 text-base"
                />
              </div>
              
              <div className="flex gap-2 overflow-x-auto pb-2">
                <Button
                  variant={filterStatus === 'all' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setFilterStatus('all')}
                  className="whitespace-nowrap"
                >
                  ทั้งหมด
                </Button>
                <Button
                  variant={filterStatus === 'warranty' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setFilterStatus('warranty')}
                  className="whitespace-nowrap"
                >
                  ในประกัน
                </Button>
                <Button
                  variant={filterStatus === 'no-warranty' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setFilterStatus('no-warranty')}
                  className="whitespace-nowrap"
                >
                  หมดประกัน
                </Button>
                <Button
                  variant={filterStatus === 'needs-service' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setFilterStatus('needs-service')}
                  className="whitespace-nowrap"
                >
                  เคยซ่อม
                </Button>
              </div>
            </div>

            {/* Customer Cards for Mobile */}
            <div className="space-y-4 lg:hidden">
              {filteredCustomers.map((customer) => (
                <Card 
                  key={customer.id}
                  className="cursor-pointer hover:shadow-md transition-shadow"
                  onClick={() => setSelectedCustomer(customer)}
                >
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h3 className="font-semibold text-lg text-blue-600">{customer.code}</h3>
                        <p className="font-medium">{customer.name}</p>
                      </div>
                      <Badge className={getGradeColor(customer.gradeLabel)}>
                        {getGradeIcon(customer.gradeLabel)}
                        {customer.gradeLabel}
                      </Badge>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div className="flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-gray-400" />
                        <span>{customer.province}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <User className="w-3 h-3 text-gray-400" />
                        <span>{customer.technician}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Wrench className="w-3 h-3 text-orange-400" />
                        <span>ซ่อม {customer.repairCount} ครั้ง</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <TrendingUp className="w-3 h-3 text-purple-400" />
                        <span>คะแนน {customer.score}</span>
                      </div>
                    </div>
                    
                    <div className="mt-3 pt-3 border-t text-xs text-gray-500">
                      <p>รุ่นเครื่อง: {customer.machineModel}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Customer Table for Desktop */}
            <Card className="hidden lg:block">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5" />
                  รายชื่อลูกค้า
                </CardTitle>
                <CardDescription>
                  แสดง {filteredCustomers.length} จาก {data?.customers?.length || 0} รายการ
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="rounded-md border overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[100px]">รหัสลูกค้า</TableHead>
                        <TableHead>ชื่อลูกค้า</TableHead>
                        <TableHead className="w-[120px]">จังหวัด</TableHead>
                        <TableHead className="w-[140px]">รุ่นเครื่องจักร</TableHead>
                        <TableHead className="w-[130px]">ช่างผู้ดูแล</TableHead>
                        <TableHead className="w-[80px] text-center">จำนวนซ่อม</TableHead>
                        <TableHead className="w-[100px] text-center">สถานะประกัน</TableHead>
                        <TableHead className="w-[80px] text-center">คะแนน</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredCustomers.map((customer) => (
                        <TableRow 
                          key={customer.id}
                          className="cursor-pointer hover:bg-blue-50 transition-colors"
                          onClick={() => setSelectedCustomer(customer)}
                        >
                          <TableCell className="font-medium text-blue-600">
                            {customer.code}
                          </TableCell>
                          <TableCell className="font-medium">{customer.name}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1">
                              <MapPin className="w-3 h-3 text-gray-400" />
                              {customer.province}
                            </div>
                          </TableCell>
                          <TableCell className="font-mono text-sm">
                            {customer.machineModel}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1">
                              <User className="w-3 h-3 text-gray-400" />
                              {customer.technician}
                            </div>
                          </TableCell>
                          <TableCell className="text-center">
                            <span className="font-semibold text-orange-600">
                              {customer.repairCount}
                            </span>
                          </TableCell>
                          <TableCell className="text-center">
                            <Badge 
                              className={`flex items-center gap-1 w-fit mx-auto ${getGradeColor(customer.gradeLabel)}`}
                            >
                              {getGradeIcon(customer.gradeLabel)}
                              {customer.gradeLabel}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-center">
                            <span className="font-medium text-purple-600">
                              {customer.score}
                            </span>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
                
                {filteredCustomers.length === 0 && (
                  <div className="text-center py-12 text-gray-500">
                    <Search className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>ไม่พบข้อมูลลูกค้าที่ตรงกับเงื่อนไขการค้นหา</p>
                    <p className="text-sm mt-1">ลองปรับเปลี่ยนคำค้นหาหรือตัวกรอง</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="pm">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="w-5 h-5" />
                  ตารางบำรุงรักษา
                </CardTitle>
                <CardDescription>
                  กำหนดการตรวจเช็คและบำรุงรักษาเครื่องจักร
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12 text-gray-500">
                  <Calendar className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p className="text-lg font-medium">ยังไม่มีข้อมูลการบำรุงรักษา</p>
                  <p className="text-sm mt-2">กำลังพัฒนาฟังก์ชันนี้...</p>
                  <Button className="mt-4" variant="outline">
                    <Plus className="w-4 h-4 mr-2" />
                    เพิ่มกำหนดการบำรุงรักษา
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="parts">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Package className="w-5 h-5" />
                  คลังอะไหล่และอุปกรณ์
                </CardTitle>
                <CardDescription>
                  จัดการสต็อกอะไหล่ การเบิกใช้ และประวัติการสั่งซื้อ
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12 text-gray-500">
                  <Package className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p className="text-lg font-medium">ยังไม่มีข้อมูลอะไหล่</p>
                  <p className="text-sm mt-2">กำลังพัฒนาฟังก์ชันนี้...</p>
                  <Button className="mt-4" variant="outline">
                    <Plus className="w-4 h-4 mr-2" />
                    เพิ่มข้อมูลอะไหล่
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Customer Detail Modal - Mobile Optimized */}
        {selectedCustomer && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <Card className="w-full max-w-3xl max-h-[90vh] overflow-y-auto">
              <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-xl text-blue-900">
                      {selectedCustomer.name}
                    </CardTitle>
                    <CardDescription className="text-blue-700">
                      รหัสลูกค้า: {selectedCustomer.code}
                    </CardDescription>
                  </div>
                  <Button 
                    variant="ghost" 
                    onClick={() => setSelectedCustomer(null)}
                    className="text-gray-500 hover:text-gray-700"
                  >
                    <X className="w-5 h-5" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-6 pt-6">
                {/* Basic Information */}
                <div>
                  <h3 className="text-lg font-semibold mb-4 text-gray-900">ข้อมูลทั่วไป</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-600">จังหวัด</label>
                      <div className="flex items-center gap-2 p-3 bg-gray-50 rounded-lg">
                        <MapPin className="w-4 h-4 text-gray-400" />
                        <span className="font-medium">{selectedCustomer.province}</span>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-600">รุ่นเครื่องจักร</label>
                      <div className="p-3 bg-gray-50 rounded-lg">
                        <span className="font-mono font-medium">{selectedCustomer.machineModel}</span>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-600">ช่างผู้ดูแล</label>
                      <div className="flex items-center gap-2 p-3 bg-gray-50 rounded-lg">
                        <User className="w-4 h-4 text-gray-400" />
                        <span className="font-medium">{selectedCustomer.technician}</span>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-600">สถานะประกัน</label>
                      <div className="p-3 bg-gray-50 rounded-lg">
                        <Badge className={getGradeColor(selectedCustomer.gradeLabel)}>
                          {getGradeIcon(selectedCustomer.gradeLabel)}
                          {selectedCustomer.gradeLabel}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Service Statistics */}
                <div>
                  <h3 className="text-lg font-semibold mb-4 text-gray-900">สถิติการใช้บริการ</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="bg-orange-50 p-4 rounded-lg border border-orange-200">
                      <div className="flex items-center gap-2 mb-2">
                        <Wrench className="w-5 h-5 text-orange-600" />
                        <span className="text-sm font-medium text-orange-800">จำนวนการซ่อม</span>
                      </div>
                      <p className="text-2xl font-bold text-orange-600">
                        {selectedCustomer.repairCount}
                      </p>
                      <p className="text-xs text-orange-600">ครั้ง</p>
                    </div>
                    <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                      <div className="flex items-center gap-2 mb-2">
                        <Clock className="w-5 h-5 text-green-600" />
                        <span className="text-sm font-medium text-green-800">ความถี่ให้บริการ</span>
                      </div>
                      <p className="text-2xl font-bold text-green-600">
                        {selectedCustomer.serviceFrequency}
                      </p>
                      <p className="text-xs text-green-600">ครั้ง/เดือน</p>
                    </div>
                    <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
                      <div className="flex items-center gap-2 mb-2">
                        <TrendingUp className="w-5 h-5 text-purple-600" />
                        <span className="text-sm font-medium text-purple-800">คะแนนสะสม</span>
                      </div>
                      <p className="text-2xl font-bold text-purple-600">
                        {selectedCustomer.score}
                      </p>
                      <p className="text-xs text-purple-600">คะแนน</p>
                    </div>
                  </div>
                </div>

                {/* Action Buttons - Mobile Optimized */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-4 border-t">
                  <Button className="w-full">
                    <Calendar className="w-4 h-4 mr-2" />
                    นัดหมาย
                  </Button>
                  <Button variant="outline" className="w-full">
                    <Wrench className="w-4 h-4 mr-2" />
                    บันทึกการซ่อม
                  </Button>
                  <Button variant="outline" className="w-full">
                    <Package className="w-4 h-4 mr-2" />
                    เบิกอะไหล่
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}