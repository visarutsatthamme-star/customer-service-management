import { NextRequest, NextResponse } from 'next/server';

// จำลองฐานข้อมูลการบำรุงรักษา
let pmSchedules = [
  {
    id: 'PM001',
    customerId: 'TUN002',
    customerName: 'SCON',
    machineModel: 'HB60Q-13',
    scheduledDate: '2024-02-15',
    technician: 'กิตติพงษ์',
    status: 'scheduled',
    type: 'monthly_check',
    description: 'ตรวจเช็ครายเดือนปกติ'
  },
  {
    id: 'PM002', 
    customerId: 'TUN003',
    customerName: 'ABC Company',
    machineModel: 'HB80Q-15',
    scheduledDate: '2024-02-20',
    technician: 'สมชาย',
    status: 'completed',
    type: 'quarterly_service',
    description: 'บำรุงรักษาไตรมาส'
  }
];

// จำลองฐานข้อมูลอะไหล่
let partsInventory = [
  {
    id: 'PART001',
    name: 'ไส้กรองน้ำมันเครื่อง',
    code: 'OF-001',
    quantity: 25,
    unit: 'ชิ้น',
    minStock: 10,
    price: 450,
    location: 'A1-01',
    lastUpdated: '2024-01-15'
  },
  {
    id: 'PART002',
    name: 'จาระบีเครื่อง',
    code: 'GL-002', 
    quantity: 8,
    unit: 'ขวด',
    minStock: 5,
    price: 320,
    location: 'B2-03',
    lastUpdated: '2024-01-20'
  },
  {
    id: 'PART003',
    name: 'สายพานลำเลียง',
    code: 'BL-003',
    quantity: 3,
    unit: 'เส้น',
    minStock: 2,
    price: 2800,
    location: 'C1-05',
    lastUpdated: '2024-01-10'
  }
];

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const type = searchParams.get('type');

  try {
    if (type === 'pm') {
      return NextResponse.json({
        success: true,
        data: pmSchedules,
        message: 'ดึงข้อมูลกำหนดการบำรุงรักษาสำเร็จ'
      });
    } else if (type === 'parts') {
      return NextResponse.json({
        success: true,
        data: partsInventory,
        message: 'ดึงข้อมูลคลังอะไหล่สำเร็จ'
      });
    } else {
      return NextResponse.json({
        success: true,
        data: {
          pm: pmSchedules,
          parts: partsInventory
        },
        message: 'ดึงข้อมูลทั้งหมดสำเร็จ'
      });
    }
  } catch (error) {
    console.error('เกิดข้อผิดพลาดในการดึงข้อมูล:', error);
    return NextResponse.json({
      success: false,
      error: 'ไม่สามารถดึงข้อมูลได้',
      message: error instanceof Error ? error.message : 'ข้อผิดพลาดที่ไม่ทราบสาเหตุ'
    }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { type, data } = body;

    if (type === 'pm') {
      // เพิ่มกำหนดการบำรุงรักษาใหม่
      const newPm = {
        id: `PM${Date.now()}`,
        ...data,
        status: 'scheduled',
        createdAt: new Date().toISOString()
      };
      pmSchedules.push(newPm);

      return NextResponse.json({
        success: true,
        data: newPm,
        message: 'เพิ่มกำหนดการบำรุงรักษาสำเร็จ'
      });
    } else if (type === 'parts') {
      // เพิ่มอะไหล่ใหม่
      const newPart = {
        id: `PART${Date.now()}`,
        ...data,
        lastUpdated: new Date().toISOString().split('T')[0]
      };
      partsInventory.push(newPart);

      return NextResponse.json({
        success: true,
        data: newPart,
        message: 'เพิ่มอะไหล่สำเร็จ'
      });
    } else if (type === 'parts-usage') {
      // บันทึกการเบิกใช้อะไหล่
      const { partId, quantity, customerId, technician } = data;
      const part = partsInventory.find(p => p.id === partId);
      
      if (!part) {
        return NextResponse.json({
          success: false,
          error: 'ไม่พบอะไหล่ที่ระบุ'
        }, { status: 404 });
      }

      if (part.quantity < quantity) {
        return NextResponse.json({
          success: false,
          error: 'สต็อกไม่เพียงพอ'
        }, { status: 400 });
      }

      part.quantity -= quantity;
      part.lastUpdated = new Date().toISOString().split('T')[0];

      const usageRecord = {
        id: `USE${Date.now()}`,
        partId,
        partName: part.name,
        quantity,
        customerId,
        technician,
        date: new Date().toISOString().split('T')[0],
        totalCost: quantity * part.price
      };

      return NextResponse.json({
        success: true,
        data: {
          usageRecord,
          updatedPart: part
        },
        message: 'บันทึกการเบิกใช้อะไหล่สำเร็จ'
      });
    }

    return NextResponse.json({
      success: false,
      error: 'ไม่ระบุประเภทข้อมูล'
    }, { status: 400 });

  } catch (error) {
    console.error('เกิดข้อผิดพลาดในการบันทึกข้อมูล:', error);
    return NextResponse.json({
      success: false,
      error: 'ไม่สามารถบันทึกข้อมูลได้',
      message: error instanceof Error ? error.message : 'ข้อผิดพลาดที่ไม่ทราบสาเหตุ'
    }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { type, id, data } = body;

    if (type === 'pm') {
      const pmIndex = pmSchedules.findIndex(pm => pm.id === id);
      if (pmIndex === -1) {
        return NextResponse.json({
          success: false,
          error: 'ไม่พบกำหนดการบำรุงรักษา'
        }, { status: 404 });
      }

      pmSchedules[pmIndex] = { ...pmSchedules[pmIndex], ...data };
      
      return NextResponse.json({
        success: true,
        data: pmSchedules[pmIndex],
        message: 'อัพเดทกำหนดการบำรุงรักษาสำเร็จ'
      });
    } else if (type === 'parts') {
      const partIndex = partsInventory.findIndex(part => part.id === id);
      if (partIndex === -1) {
        return NextResponse.json({
          success: false,
          error: 'ไม่พบอะไหล่'
        }, { status: 404 });
      }

      partsInventory[partIndex] = { 
        ...partsInventory[partIndex], 
        ...data,
        lastUpdated: new Date().toISOString().split('T')[0]
      };
      
      return NextResponse.json({
        success: true,
        data: partsInventory[partIndex],
        message: 'อัพเดทข้อมูลอะไหล่สำเร็จ'
      });
    }

    return NextResponse.json({
      success: false,
      error: 'ไม่ระบุประเภทข้อมูล'
    }, { status: 400 });

  } catch (error) {
    console.error('เกิดข้อผิดพลาดในการอัพเดทข้อมูล:', error);
    return NextResponse.json({
      success: false,
      error: 'ไม่สามารถอัพเดทข้อมูลได้',
      message: error instanceof Error ? error.message : 'ข้อผิดพลาดที่ไม่ทราบสาเหตุ'
    }, { status: 500 });
  }
}