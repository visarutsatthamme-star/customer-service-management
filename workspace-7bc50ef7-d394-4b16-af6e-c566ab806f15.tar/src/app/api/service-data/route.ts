import { NextRequest, NextResponse } from 'next/server';

const GOOGLE_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbxP13-5puBL-IICp3erVwmOQqFtOzJPhSKdTyMl8sq-g7DZbRE7gmYufIZzIIoaRfqDyQ/exec';

export async function GET(request: NextRequest) {
  try {
    console.log('กำลังดึงข้อมูลจาก Google Apps Script...');
    
    const response = await fetch(GOOGLE_SCRIPT_URL, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'NextJS-Customer-Service-System/1.0',
      },
      redirect: 'follow',
      // เพิ่ม timeout เพื่อป้องกันการรอนานเกินไป
      signal: AbortSignal.timeout(30000),
    });

    if (!response.ok) {
      console.error('Google Script API error:', response.status, response.statusText);
      throw new Error(`ไม่สามารถดึงข้อมูลได้: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    console.log('ดึงข้อมูลสำเร็จ:', JSON.stringify(data, null, 2));

    // ตรวจสอบว่าข้อมูลมีโครงสร้างที่ถูกต้องหรือไม่
    if (!data || typeof data !== 'object') {
      throw new Error('ข้อมูลที่ได้รับไม่ถูกต้อง');
    }

    return NextResponse.json({
      success: true,
      data: data,
      timestamp: new Date().toISOString(),
      message: 'ดึงข้อมูลสำเร็จ'
    });

  } catch (error) {
    console.error('เกิดข้อผิดพลาดในการดึงข้อมูล:', error);
    
    // ส่งข้อมูลตัวอย่างเมื่อ API ล้มเหลว
    const fallbackData = {
      customers: [
        {
          id: "TUN002",
          code: "TUN002",
          name: "SCON",
          province: "ขอนแก่น",
          machineModel: "HB60Q-13",
          technician: "กิตติพงษ์",
          serviceFrequency: 0,
          repairCount: 0,
          totalPurchase: 0,
          score: 0,
          gradeLabel: "ในประกัน"
        },
        {
          id: "TUN003",
          code: "TUN003",
          name: "ABC Company",
          province: "กรุงเทพมหานคร",
          machineModel: "HB80Q-15",
          technician: "สมชาย",
          serviceFrequency: 2,
          repairCount: 3,
          totalPurchase: 150000,
          score: 85,
          gradeLabel: "หมดประกัน"
        }
      ],
      pm: [],
      parts: [],
      visits: {}
    };

    return NextResponse.json({
      success: true,
      data: fallbackData,
      timestamp: new Date().toISOString(),
      message: 'ใช้ข้อมูลตัวอย่าง (ไม่สามารถเชื่อมต่อ Google Apps Script)',
      warning: 'Using fallback data - Google Apps Script connection failed'
    });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    console.log('ได้รับคำขอ POST:', body);
    
    // สำหรับอนาคต - ส่งข้อมูลกลับไปยัง Google Apps Script
    // ตอนนี้ยังไม่ได้ implement การส่งข้อมูลกลับ
    
    return NextResponse.json({
      success: true,
      message: 'รับข้อมูลเรียบร้อยแล้ว',
      timestamp: new Date().toISOString(),
      received_data: body
    });

  } catch (error) {
    console.error('เกิดข้อผิดพลาดในคำขอ POST:', error);
    
    return NextResponse.json({
      success: false,
      error: 'ไม่สามารถประมวลผลคำขอได้',
      message: error instanceof Error ? error.message : 'ข้อผิดพลาดที่ไม่ทราบสาเหตุ',
      timestamp: new Date().toISOString()
    }, { status: 500 });
  }
}