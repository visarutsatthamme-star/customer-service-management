import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "ระบบจัดการบริการลูกค้า",
  description: "ระบบจัดการบริการลูกค้าภาษาไทยสำหรับธุรกิจของคุณ - Customer Service Management System",
  keywords: ["ระบบบริการลูกค้า", "จัดการลูกค้า", "ซ่อมบำรุง", "คลังอะไหล่", "PWA", "มือถือ"],
  authors: [{ name: "Customer Service Team" }],
  icons: {
    icon: "/icons/icon-192x192.png",
    apple: "/icons/icon-192x192.png",
  },
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "Customer Service",
  },
  formatDetection: {
    telephone: false,
  },
  openGraph: {
    title: "ระบบจัดการบริการลูกค้า",
    description: "ระบบจัดการบริการลูกค้าภาษาไทยสำหรับธุรกิจของคุณ",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "ระบบจัดการบริการลูกค้า",
    description: "ระบบจัดการบริการลูกค้าภาษาไทยสำหรับธุรกิจของคุณ",
  },
};

export const viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="th" suppressHydrationWarning>
      <head>
        <meta name="theme-color" content="#3b82f6" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
        <meta name="apple-mobile-web-app-title" content="Customer Service" />
        <link rel="apple-touch-icon" href="/icons/icon-192x192.png" />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
