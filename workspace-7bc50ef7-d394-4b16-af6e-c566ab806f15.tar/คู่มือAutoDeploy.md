# 🚀 คู่มือการตั้งค่า Auto Deploy Next.js บน Vercel

## 📋 ภาพรวม

Auto Deploy คือระบบที่ Deploy แอปพลิเคชันอัตโนมัติเมื่อมีการเปลี่ยนแปลงโค้ดใน repository ช่วยลดความผิดพลาดและเพิ่มความเร็วในการพัฒนา

---

## 🎯 สิ่งที่ตั้งค่าไว้แล้ว

### ✅ **CI/CD Pipeline**
- ✅ **GitHub Actions** - 2 workflows สำหรับ build และ deploy
- ✅ **Quality Gates** - ESLint, TypeScript, Build tests
- ✅ **Auto Deploy** - Push to main = auto deploy
- ✅ **Health Checks** - ตรวจสอบสถานะระบบหลัง deploy
- ✅ **Notifications** - แจ้งเตือนเมื่อ deploy สำเร็จ

### 🔧 **Vercel Configuration**
- ✅ **Framework Detection** - Next.js อัตโนมัติ
- ✅ **Build Optimization** - Build caching และ optimization
- ✅ **Security Headers** - XSS protection, CORS, etc.
- ✅ **API Routes** - Edge functions สำหรับ API
- ✅ **Static Assets** - CDN caching สำหรับ images, icons

---

## 🛠️ วิธีการตั้งค่า (3 ขั้นตอน)

### 1️⃣ **เตรียม GitHub Repository**

#### **Push โค้ดขึ้น GitHub**
```bash
# ถ้ายังไม่มี repository
git init
git add .
git commit -m "feat: Add customer service management system with auto deploy"

# เชื่อมต่อกับ remote
git remote add origin https://github.com/yourusername/customer-service-management.git
git push -u origin main
```

#### **ตรวจสอบไฟล์ที่จำเป็น**
- ✅ `.github/workflows/deploy.yml` - Auto deploy workflow
- ✅ `.github/workflows/quality-check.yml` - Quality checks
- ✅ `vercel.json` - Vercel configuration
- ✅ `scripts/pre-deploy.sh` - Pre-deploy checks
- ✅ `scripts/post-deploy.sh` - Post-deploy tasks
- ✅ `src/app/api/health/route.ts` - Health check API

### 2️⃣ **ตั้งค่า Vercel Project**

#### **สร้าง Vercel Project**
1. เปิด [vercel.com](https://vercel.com)
2. Login ด้วย GitHub
3. คลิก **"Add New..."** > **"Project"**
4. เลือก repository `customer-service-management`
5. Vercel จะ detect Next.js อัตโนมัติ
6. คลิก **"Deploy"**

#### **ตั้งค่า Environment Variables**
ใน Vercel Dashboard > Settings > Environment Variables:
```bash
# Required
NEXT_PUBLIC_GOOGLE_SCRIPT_URL=https://script.google.com/macros/s/AKfycbxP13-5puBL-IICp3erVwmOQqFtOzJPhSKdTyMl8sq-g7DZbRE7gmYufIZzIIoaRfqDyQ/exec
NEXT_PUBLIC_APP_NAME=ระบบจัดการบริการลูกค้า
NEXT_PUBLIC_ENABLE_PWA=true

# Optional (for GitHub Actions)
VERCEL_TOKEN=your_vercel_token
ORG_ID=your_org_id
PROJECT_ID=your_project_id
PROJECT_NAME=customer-service-management
```

#### **ตั้งค่า Deploy Hooks**
- **GitHub Integration**: Settings > GitHub > เลือก repository
- **Auto Deploy**: Enable "Deploy on Push"
- **Branch Protection**: Main branch only
- **Preview Deployments**: Enable for pull requests

### 3️⃣ **ตั้งค่า GitHub Secrets**

#### **ใน GitHub Repository > Settings > Secrets**
```bash
# Vercel Integration
VERCEL_TOKEN=vercel_token_from_vercel_account
ORG_ID=vercel_org_id
PROJECT_ID=vercel_project_id
PROJECT_NAME=customer-service-management

# Environment Variables
NEXT_PUBLIC_GOOGLE_SCRIPT_URL=https://script.google.com/macros/s/...
NEXT_PUBLIC_APP_NAME=ระบบจัดการบริการลูกค้า
NEXT_PUBLIC_ENABLE_PWA=true

# Optional Notifications
SLACK_WEBHOOK=slack_webhook_url
DISCORD_WEBHOOK=discord_webhook_url
```

---

## 🔄 CI/CD Pipeline Flow

```
Git Push to Main Branch
        ↓
GitHub Actions Triggered
        ↓
Quality Check Workflow
├── ESLint Check
├── TypeScript Check
├── Prettier Check
├── Build Test
└── Bundle Size Check
        ↓
Deploy Workflow (if quality passes)
├── Install Dependencies
├── Build Project
├── Deploy to Vercel
└── Health Check
        ↓
Production URL Ready
```

---

## 📊 Monitoring และ Notifications

### 🔍 **Auto Monitoring**
- ✅ **Build Status** - GitHub Actions dashboard
- ✅ **Deploy Status** - Vercel dashboard
- ✅ **Health Checks** - `/api/health` endpoint
- ✅ **Error Tracking** - Vercel logs
- ✅ **Performance** - Vercel Analytics

### 📧 **Health Check Endpoint**
```bash
# ตรวจสอบสถานะระบบ
curl https://your-app.vercel.app/api/health

# Response example
{
  "status": "healthy",
  "timestamp": "2024-11-18T10:30:00.000Z",
  "uptime": 3600,
  "environment": "production",
  "version": "1.0.0",
  "services": {
    "api": "operational",
    "database": "not connected (using Google Apps Script)",
    "cache": "operational"
  }
}
```

### 📱 **Notifications Setup**
```yaml
# .github/workflows/deploy.yml
- name: 📧 Notify on Success
  if: success()
  run: |
    curl -X POST -H 'Content-type: application/json' \
    --data "{\"text\":\"🚀 Deployed successfully!\n🌐 ${{ secrets.VERCEL_URL }}\"}" \
    ${{ secrets.SLACK_WEBHOOK }}
```

---

## 🚨 การแก้ไขปัญหา

### ❌ **Build Failed**
```bash
# ตรวจสอบ GitHub Actions
# 1. ไปที่ Actions tab ใน GitHub
# 2. คลิก workflow ที่ fail
# 3. ดู error logs
# 4. แก้ไขและ push ใหม่

# Local debugging
npm run build
npm run lint
```

### 🔧 **Deploy Failed**
```bash
# ตรวจสอบ Vercel logs
vercel logs

# Manual deploy
vercel --prod
```

### 🔄 **Rollback**
```bash
# กลับไป commit ก่อนหน้า
git checkout previous_commit_hash
git push --force-with-lease origin main
```

---

## 🎯 Best Practices

### 📋 **Before Each Deploy**
- [ ] Tests pass
- [ ] Build succeeds
- [ ] Linting clean
- [ ] Environment variables set
- [ ] Documentation updated

### 🚀 **Deploy Process**
- [ ] Push to main branch
- [ ] Monitor GitHub Actions
- [ ] Check Vercel dashboard
- [ ] Verify health endpoint
- [ ] Test critical features

### 📊 **After Deploy**
- [ ] Check production URL
- [ ] Monitor error rates
- [ ] Verify performance
- [ ] Test mobile functionality
- [ ] Check PWA installation

---

## 🔧 Advanced Configuration

### 🌍 **Multi-Environment**
```yaml
# .github/workflows/deploy.yml
on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  deploy-production:
    if: github.ref == 'refs/heads/main'
    # Production deploy steps
    
  deploy-staging:
    if: github.ref == 'refs/heads/develop'
    # Staging deploy steps
```

### 📦 **Build Optimization**
```json
// vercel.json
{
  "buildCommand": "npm run build",
  "installCommand": "npm ci",
  "framework": "nextjs",
  "functions": {
    "src/app/api/**/*.ts": {
      "maxDuration": 30
    }
  }
}
```

### 🔒 **Security**
```json
// vercel.json headers
{
  "headers": [
    {
      "source": "/(.*)",
      "headers": [
        {
          "key": "X-Content-Type-Options",
          "value": "nosniff"
        },
        {
          "key": "X-Frame-Options",
          "value": "DENY"
        },
        {
          "key": "Strict-Transport-Security",
          "value": "max-age=31536000; includeSubDomains"
        }
      ]
    }
  ]
}
```

---

## 🎉 การทดสอบ Auto Deploy

### 🧪 **Test Scenario 1: Normal Deploy**
```bash
# 1. แก้ไขโค้ดเล็กน้อย
echo "// Test auto deploy" >> src/app/page.tsx

# 2. Commit และ push
git add .
git commit -m "test: Auto deploy functionality"
git push origin main

# 3. ตรวจสอบ
# - GitHub Actions ทำงานไหม
# - Vercel deploy สำเร็จไหม
# - Health endpoint ตอบไหม
```

### 🧪 **Test Scenario 2: Rollback**
```bash
# 1. ดู commit history
git log --oneline

# 2. กลับไป commit ก่อนหน้า
git checkout abc1234

# 3. Force push
git push --force-with-lease origin main
```

---

## 📈 Performance Monitoring

### 📊 **Key Metrics**
- **Build Time**: < 3 minutes
- **Deploy Time**: < 2 minutes
- **Uptime**: > 99.9%
- **Error Rate**: < 1%
- **Page Load**: < 2 seconds

### 🔍 **Monitoring Tools**
- **Vercel Analytics**: Built-in analytics
- **GitHub Actions**: CI/CD monitoring
- **Health Endpoint**: Custom monitoring
- **Lighthouse**: Performance audits

---

## 🎯 สรุป

### ✅ **สิ่งที่ได้**
- 🔄 **Auto Deploy** - Push to main = auto deploy
- 🧪 **Quality Gates** - ESLint, TypeScript, Build
- 🔍 **Health Monitoring** - API health checks
- 📧 **Environment Management** - Production variables
- 📊 **Error Tracking** - Logs and notifications

### 🚀 **ผลลัพธ์**
- ⚡ **Deploy Speed** - 2-3 minutes
- 🌍 **Zero Downtime** - Seamless deployments
- 📱 **Mobile Ready** - PWA พร้อมใช้
- 🔒 **Secure** - HTTPS และ security headers
- 📈 **Scalable** - Vercel CDN ทั่วโลก

---

## 🎊 **ยินดีด้วย!**

**ระบบจัดการบริการลูกค้าของคุณพร้อมใช้งานแบบ Auto Deploy บน Vercel แล้ว!** 🎉✨

### 🚀 **เริ่มต้นได้เลย:**
1. **Push โค้ด**: `git push origin main`
2. **Monitor**: GitHub Actions และ Vercel
3. **Verify**: Production URL และ health check
4. **Enjoy**: Auto deploy ทุกครั้ง!

**ทุกการแก้ไขโค้ดจะ Deploy อัตโนมัติ - พร้อมให้บริการจริง!** 🌟🚀