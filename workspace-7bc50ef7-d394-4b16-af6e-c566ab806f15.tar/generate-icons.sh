#!/bin/bash

# สร้างไอคอนขนาดต่างๆ จากรูปภาพหลัก
convert public/icons/icon-1024x1024.png -resize 72x72 public/icons/icon-72x72.png
convert public/icons/icon-1024x1024.png -resize 96x96 public/icons/icon-96x96.png
convert public/icons/icon-1024x1024.png -resize 128x128 public/icons/icon-128x128.png
convert public/icons/icon-1024x1024.png -resize 144x144 public/icons/icon-144x144.png
convert public/icons/icon-1024x1024.png -resize 152x152 public/icons/icon-152x152.png
convert public/icons/icon-1024x1024.png -resize 192x192 public/icons/icon-192x192.png
convert public/icons/icon-1024x1024.png -resize 384x384 public/icons/icon-384x384.png
convert public/icons/icon-1024x1024.png -resize 512x512 public/icons/icon-512x512.png

echo "สร้างไอคอนทุกขนาดเรียบร้อยแล้ว!"