#!/bin/bash

# 🚀 Auto Deploy Setup Script for Customer Service Management
# สคริปต์นี้จะช่วยตั้งค่า Auto Deploy ทั้งหมด

echo "🎯 ตั้งค่า Auto Deploy Next.js บน Vercel"
echo "=================================="

# ตรวจสอบว่าอยู่ใน git repository หรือไม่
if [ ! -d ".git" ]; then
    echo "📦 กำลังสร้าง Git repository..."
    git init
    git add .
    git commit -m "feat: Initial commit - Customer Service Management System"
    echo "✅ Git repository สร้างเรียบร้อยแล้ว"
else
    echo "✅ พบ Git repository อยู่แล้ว"
fi

# ตรวจสอบว่ามี remote หรือไม่
if ! git remote get-url origin 2>/dev/null; then
    echo "🔗 กรุณาเพิ่ม GitHub remote:"
    echo "git remote add origin https://github.com/YOUR_USERNAME/customer-service-management.git"
    echo ""
    echo "📋 แก้ไข YOUR_USERNAME เป็น username ของคุณ"
    echo "จากนั้นรัน: git push -u origin main"
else
    echo "✅ พบ Git remote อยู่แล้ว"
fi

echo ""
echo "🌐 ขั้นตอนต่อไป:"

echo "1️⃣ สร้าง GitHub Repository"
echo "   - ไปที่: https://github.com/new"
echo "   - Repository name: customer-service-management"
echo "   - Description: ระบบจัดการบริการลูกค้าภาษาไทย"
echo "   - Public: ✅"
echo "   - Add README: ✅"
echo ""

echo "2️⃣ เชื่อมต่อ GitHub กับ Vercel"
echo "   - ไปที่: https://vercel.com"
echo "   - Login ด้วย GitHub"
echo "   - คลิก 'Add New...' > 'Project'"
echo "   - Import repository: customer-service-management"
echo "   - Vercel จะ detect Next.js อัตโนมัติ"
echo "   - คลิก 'Deploy'"
echo ""

echo "3️⃣ ตั้งค่า Environment Variables บน Vercel"
echo "   - ไปที่: Project Settings > Environment Variables"
echo "   - เพิ่มตัวแปรเหล่านี้:"
echo "     NEXT_PUBLIC_GOOGLE_SCRIPT_URL=https://script.google.com/macros/s/AKfycbxP13-5puBL-IICp3erVwmOQqFtOzJPhSKdTyMl8sq-g7DZbRE7gmYufIZzIIoaRfqDyQ/exec"
echo "     NEXT_PUBLIC_APP_NAME=ระบบจัดการบริการลูกค้า"
echo "     NEXT_PUBLIC_ENABLE_PWA=true"
echo ""

echo "4️⃣ ตั้งค่า GitHub Secrets (สำหรับ CI/CD)"
echo "   - ไปที่: GitHub repo > Settings > Secrets and variables > Actions"
echo "   - เพิ่ม secrets:"
echo "     VERCEL_TOKEN=your_vercel_token"
echo "     ORG_ID=your_vercel_org_id"
echo "     PROJECT_ID=your_vercel_project_id"
echo "     PROJECT_NAME=customer-service-management"
echo ""

echo "5️⃣ เปิดใช้งาน Auto Deploy"
echo "   - ใน Vercel: Settings > Git Integration"
echo "   - เลือก repository ของคุณ"
echo "   - Enable 'Deploy on Push'"
echo "   - Set main branch as production"
echo ""

echo "🎯 หลังจากนี้ทุกครั้งที่ push ไป main branch:"
echo "   - GitHub Actions จะทำงานอัตโนมัติ"
echo "   - Build และ deploy ไป Vercel"
echo "   - แจ้งเตือนถ้ามีปัญหา"
echo ""

echo "📋 ไฟล์ที่สร้างไว้สำหรับ Auto Deploy:"
echo "   ✅ .github/workflows/deploy.yml - Main deploy workflow"
echo "   ✅ .github/workflows/quality-check.yml - Quality checks"
echo "   ✅ vercel.json - Vercel configuration"
echo "   ✅ scripts/pre-deploy.sh - Pre-deploy checks"
echo "   ✅ scripts/post-deploy.sh - Post-deploy tasks"
echo "   ✅ src/app/api/health/route.ts - Health check API"
echo "   ✅ คู่มือAutoDeploy.md - Full documentation"
echo ""

echo "🧪 ทดสอบการทำงาน:"
echo "   npm run build    # ทดสอบ build"
echo "   npm run lint     # ทดสอบ linting"
echo "   npm run dev      # ทดสอบ development"
echo ""

echo "🎉 เมื่อตั้งค่าเสร็จ:"
echo "   git push origin main"
echo "   # รอประมาณ 2-3 นาที"
echo "   # แอปจะพร้อมใช้งานบน Vercel!"
echo ""

echo "📚 คู่มือเพิ่มเติม:"
echo "   - คู่มือAutoDeploy.md - คู่มือ Auto Deploy ฉบับสมบูรณ์"
echo "   - คู่มือVercel.md - คู่มือการใช้ Vercel"
echo "   - คู่มือมือถือ.md - คู่มือการใช้บนมือถือ"
echo ""

echo "🚀 พร้อม Deploy แบบ Auto แล้ว!"